
 En : 
    The designed site is a single page for loading on the host and this site is designed as a landing page
It is enough to create a virtual environment with the command
python -m vevn env
cd env/script
activity
in Windsor
In a Linux environment
virtualenv -p python -m env
source env/bin/activate
 is
 And in the virtual environment, the command is enough
 pip install -r requirements.txt
 Run and order
 python3 manage.py runserver ---- in linux
 python manage.py runserver ---- in windows

 Fa : 
    سایت طراحی شده تک صفحه ای برای لود کردن در هاست می باشد و این سایت طراحی به صورت لندینگ پیج می باشد 
فقط کافی هست یک محیط مجازی ایجاد کنیم که با دستور 
python -m vevn env
cd env/script
activite
در ویندور 
در محیط لینوکس
virtualenv -p python -m env
source env/bin/activate
 است 
 و در محیط virtual کافی هست دستور 
 pip install -r requirements.txt
 اجرا کرده و دستور
 python3 manage.py runserver    ---- in linux
 python manage.py runserver    ---- in windows