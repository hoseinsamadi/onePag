from django.urls import path
from oneApp.views import *

urlpatterns = [
    path('',home_view),

]
