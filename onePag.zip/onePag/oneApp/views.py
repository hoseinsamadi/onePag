from django.shortcuts import render
from django.http import HttpResponse ,JsonResponse
# reate your views here.
def home_view(request):
    return render(request, 'index.html')
    #return render(request, 'index.html')